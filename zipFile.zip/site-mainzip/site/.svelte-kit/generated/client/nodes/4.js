import * as universal from "../../../../src/routes/blog/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/blog/[slug]/+page.svelte";