# Rain FAQ Website

## Overview

A website showcasing the Rain Discord client for Android and iOS. Features a dark Discord-like theme with purple/blue accents, styled similar to Vencord.dev. The site includes information about Rain and Kettu, feature highlights, and a FAQ section with commonly asked questions about the projects.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite with custom plugins for meta images and development tooling
- **Animations**: Framer Motion for UI transitions

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript compiled with tsx for development, esbuild for production
- **File Handling**: Multer for file uploads, AdmZip for ZIP processing
- **Image Processing**: ImageTracerJS for raster-to-vector conversion
- **Architecture Pattern**: RESTful API with file upload endpoints

### Core Functionality
- **Icon Discovery**: Extracts and analyzes icons from uploaded ZIP files
- **Name Mapping**: Uses a crosswalk dictionary to suggest Android/Kotlin-compatible names from React Native icon names
- **Vector Conversion**: Converts raster images to SVG, then to Android VectorDrawable XML format
- **Export**: Generates downloadable ZIP packages with converted icons and manifest files

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM (schema defined but primarily used for user management)
- **File Storage**: Temporary file storage in `/tmp` directories for processing uploads
- **In-Memory Option**: MemStorage class available for development/testing without database

### Build Configuration
- Separate Vite configs for development (`vite.config.ts`) and static deployment (`vite.config.static.ts`)
- Custom build script using esbuild for server bundling with dependency allowlisting
- Vercel deployment configuration with SPA rewrites

## External Dependencies

### Third-Party Services
- **ThemesPlus Repository**: Fetches icon pack lists from `https://raw.githubusercontent.com/nexpid/ThemesPlus/main/iconpacks/list.json`

### Key Libraries
- **UI Components**: Radix UI primitives wrapped by shadcn/ui
- **File Processing**: JSZip (client-side), AdmZip and Archiver (server-side)
- **Image Tracing**: ImageTracerJS for bitmap-to-SVG conversion
- **Validation**: Zod for schema validation

### Database
- PostgreSQL via Drizzle ORM (connection via `DATABASE_URL` environment variable)
- Schema includes basic user table for potential authentication features